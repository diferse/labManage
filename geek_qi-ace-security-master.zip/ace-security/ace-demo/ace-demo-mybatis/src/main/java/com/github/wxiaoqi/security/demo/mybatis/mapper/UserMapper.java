package com.github.wxiaoqi.security.demo.mybatis.mapper;

import com.github.wxiaoqi.security.demo.mybatis.entity.User;
import tk.mybatis.mapper.common.Mapper;

public interface UserMapper extends Mapper<User> {
}