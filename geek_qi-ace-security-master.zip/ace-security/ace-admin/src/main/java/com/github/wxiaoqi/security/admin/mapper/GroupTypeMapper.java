package com.github.wxiaoqi.security.admin.mapper;

import com.github.wxiaoqi.security.admin.entity.GroupType;
import tk.mybatis.mapper.common.Mapper;

public interface GroupTypeMapper extends Mapper<GroupType> {
}