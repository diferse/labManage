package com.sohu.cache.constant;

/**
 * 空对象常量
 * @author leifu
 * @Date 2016-1-26
 * @Time 下午9:27:23
 */
public class EmptyObjectConstant {

	public static String EMPTY_STRING = "";
	public static String[] EMPTY_STRING_ARRAY = new String[0];

}