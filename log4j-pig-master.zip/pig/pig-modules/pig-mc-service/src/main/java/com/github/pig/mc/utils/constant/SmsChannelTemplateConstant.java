package com.github.pig.mc.utils.constant;

/**
 * @author lengleng
 * @date 2018/1/16
 * 短信通道模板常量
 */
public interface SmsChannelTemplateConstant {
    /**
     * 登录验证码
     */
    String LOGIN_NAME_LOGIN = "loginCodeChannel";
}
