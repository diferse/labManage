package com.xfdmao.fcat.user.service;

import com.xfdmao.fcat.common.service.BaseService;
import com.xfdmao.fcat.user.entity.TElement;
import com.xfdmao.fcat.user.entity.TGroupType;

/**
 * Created by xiangfei on 2017/10/16.
 */
public interface TGroupTypeService extends BaseService<TGroupType>{

}
