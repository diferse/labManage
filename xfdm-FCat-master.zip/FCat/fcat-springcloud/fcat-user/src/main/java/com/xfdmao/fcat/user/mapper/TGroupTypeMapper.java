package com.xfdmao.fcat.user.mapper;

import com.xfdmao.fcat.user.entity.TGroupType;
import tk.mybatis.mapper.common.Mapper;

public interface TGroupTypeMapper extends Mapper<TGroupType> {
}