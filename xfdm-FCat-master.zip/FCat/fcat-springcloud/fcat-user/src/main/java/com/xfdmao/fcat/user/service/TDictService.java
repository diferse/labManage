package com.xfdmao.fcat.user.service;

import com.xfdmao.fcat.common.service.BaseService;
import com.xfdmao.fcat.user.entity.TDict;

/**
 * Created by fier on 2017/11/28.
 */
public interface TDictService extends BaseService<TDict>{
}
