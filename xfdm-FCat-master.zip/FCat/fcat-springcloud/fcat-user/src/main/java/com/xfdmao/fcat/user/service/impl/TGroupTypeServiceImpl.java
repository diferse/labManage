package com.xfdmao.fcat.user.service.impl;

import com.xfdmao.fcat.common.service.impl.BaseServiceImpl;
import com.xfdmao.fcat.user.entity.TGroupType;
import com.xfdmao.fcat.user.mapper.TGroupTypeMapper;
import com.xfdmao.fcat.user.service.TGroupTypeService;
import org.springframework.stereotype.Service;

/**
 * Created by xiangfei on 2017/10/17.
 */
@Service
public class TGroupTypeServiceImpl extends BaseServiceImpl<TGroupTypeMapper,TGroupType> implements TGroupTypeService {

}
