package com.xfdmao.fcat.common.bean;

/**
 * ${DESCRIPTION}
 *
 * @author xiangfei
 * @create 2017-06-08 17:31
 */
public class Page {
    int num;
    int size;

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
