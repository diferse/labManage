# 自动生成代码
```
mvn mybatis-generator:generate

```