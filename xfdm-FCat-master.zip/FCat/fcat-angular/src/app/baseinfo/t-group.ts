/**
 * Created by F1 on 2017/6/1.
 */
export class TGroup {
  id: number;
  code: string;
  name: string;
  parentId:number;
  path:string;
  groupTypeId:number;
  createTime:string;
  updateTime:string;
}
