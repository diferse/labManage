/**
 * Created by F1 on 2017/6/1.
 */
export class TMenu {
  id: number;
  code: string;
  title: string;
  parentId: number;
  href: string;
  icon: string;
  orderNum: string;
  path: string;
  enabled: string = "Y";
  createTime:string;
  updateTime:string;
}
