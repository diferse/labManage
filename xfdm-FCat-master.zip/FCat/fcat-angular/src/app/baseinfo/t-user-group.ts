/**
 * Created by F1 on 2017/6/1.
 */
export class TUserGroup {
  id: number;
  groupId: number;
  userId: number;
  type:string;
}
