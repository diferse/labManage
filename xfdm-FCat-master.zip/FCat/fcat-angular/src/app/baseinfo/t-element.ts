/**
 * Created by F1 on 2017/6/1.
 */
export class TElement {
  id: number;
  code: string;
  type: string;
  name: number;
  uri: string;
  menuId: number;
  parentId: string;
  path: string;
  method: string;
  createTime:string;
  updateTime:string;
}
