export class TUserLog{
  id:number;
  username:string;
  optTime:Date;
  sessionId:string;
  action:string;
  method:string;
  createTime:Date;
}
