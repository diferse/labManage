/**
 * Created by F1 on 2017/6/1.
 */
export class TUser {
  id: number;
  name: string;
  sex: string = 'S';
  mobilePhone: string;
  telPhone: string;
  email: string;
  address: string;
  username: string;
  password: string;
  birthday: string;
  status:string;
  createTime:string;
  updateTime:string;
}
