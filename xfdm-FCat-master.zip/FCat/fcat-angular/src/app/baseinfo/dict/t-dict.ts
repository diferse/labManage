export class TDict{
  id:number;
  code:string;
  name:string;
  value:string;
  sort:number;
  createTime:Date;
  updateTime:Date;
}
